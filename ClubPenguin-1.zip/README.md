Auroris - An AS2 Club Penguin Emulator used for Club Penguin Rewritten.

Supports Card Jitsu and Sled Racing.

Licensed under GPLV3